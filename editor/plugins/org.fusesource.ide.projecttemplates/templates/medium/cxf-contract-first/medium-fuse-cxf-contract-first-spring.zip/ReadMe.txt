Camel Spring  CXF Contract First Project
===============================================

This project shows a Contract-first Web service (WSDL-based) exposed
via Apache Camel.

To build this project use

    mvn install

To run this project use the following Maven goal

    mvn camel:run

For more help see the Apache Camel documentation

    http://camel.apache.org/
